# DEPRECATED Python Protobuf implementation for Terra

Terra Proto python library will not be maintained any further by TFL officialy. 

Alternative options to this library can be found here:
- GoLang [Terra Core](https://github.com/terra-money/core) clients, 
- JavaScript [@terra-money/terra.proto](https://www.npmjs.com/package/@terra-money/terra.proto/),
- Rust [terra-proto-rs](https://crates.io/crates/terra-proto-rs).